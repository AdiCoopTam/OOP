public class TestRunner {
    public static void main(String[] args) {
        SpaceshipDepositoryTest.checkEverything();
        BoopingSiteTest.checkEverything();
    }
}
