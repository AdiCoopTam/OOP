import oop.ex2.*;
/**
 * This class manages the types of the space ships and take care of the different types typical behavior.
 *
 * @author adi_hava
 */

public class ActionZone {
    /**
     * the ship that in action
     */
    SpaceShip ship;

    /**
     * the current game that runs
     */
    SpaceWars game;

    /**
     * the closest ship to the ship we manage
     */
    SpaceShip clShip;

    /**
     * the angle to the closest ship
     */
    double clAngle;

    /**
     * the distance to the closest ship
     */
    double clDistance;

    /**
     * the angle that to the current round. the default is 0
     */
    int myAngle;

    /**
     * the parameter that will set the acceleration of the ship. true if it will, false otherwise. the
     * default is false
     */
    boolean acc;

    /**
     * the constructer of the action zone
     *
     * @param game the current game we play with
     * @param ship the current ship we manage
     *
     *all the other parameters are an information about the ship.
     */
    public ActionZone(SpaceShip ship,
                      SpaceWars game) {
        this.ship = ship;
        this.game = game;
        this.clShip = game.getClosestShipTo(ship);
        this.clAngle = ship.myPhysics.angleTo(clShip.myPhysics);
        this.clDistance = ship.myPhysics.distanceFrom(clShip.myPhysics);
        this.myAngle = 0;
        this.acc = false;


    }

    /**
     * this function chooses the right action function by the space ship type given
     */

    public void chooseFuncion() {
        switch (ship.shipType) {
            case "h":
                actLikeHuman();
                break;
            case "r":
                actLikeRunner();
                break;
            case "b":
                actLikeBasher();
                break;
            case "a":
                actLikeAggressive();
                break;
            case "d":
                actLikeDrunken();
            case "s":
                actLikeSpecial();
        }
    }

    /**
     * this function manages the behavior of the human player. it picks an action by the bottoms which are
     * pressed
     */
    public void actLikeHuman() {
        if (game.getGUI().isLeftPressed()) {
            myAngle++;
        }
        if (game.getGUI().isRightPressed()) {
            myAngle--;
        }
        if (game.getGUI().isUpPressed()) {
            ship.myPhysics.move(true, myAngle);
        }
        ship.myPhysics.move(false, myAngle);
        if (game.getGUI().isTeleportPressed()) {
            ship.teleport();
        }
        if (game.getGUI().isShotPressed()) {
            ship.fire(game);
        }
        if (game.getGUI().isShieldsPressed()) {
            ship.shieldOn();
        }
    }

    /**
     * the runner will run away from fighting. He will try to teleport if the closest ship is too close to
     * him.
     */
    public void actLikeRunner() {
        if (Math.abs(clAngle) < 0.23 && clDistance < 0.25) {
            ship.teleport();
        } else if (clAngle < 0) {
            myAngle = 1;
            ship.myPhysics.move(true, myAngle);
        } else if (clAngle > 0) {
            myAngle = -1;
            ship.myPhysics.move(true, myAngle);
        }
        ship.myPhysics.move(true, myAngle);
    }

    /**
     * the basher will try to collide with other ships.
     */
    public void actLikeBasher() {
        if (clDistance <= 0.19) {
            ship.shieldOn();
        }
        goAgainst();
    }

    /** this is an assist function to the basher and the agressive space ship. It makes the ship chase
     * after the closest ship.
     * */
    public void goAgainst(){
     if (clAngle < 0) {
        myAngle = -1;
        ship.myPhysics.move(true, myAngle);
    } else if (clAngle > 0) {
        myAngle = 1;
        ship.myPhysics.move(true, myAngle);
    }
        ship.myPhysics.move(true, myAngle);
    }

    /**this ship tries to harm the other ships. It tries to fire on them and get close to them.*/
    public void actLikeAggressive() {
        if (Math.abs(clAngle) < 0.21){
            ship.fire(game);
        }
        goAgainst();
    }

    /**
     * this ships moves randomly on the board, because the pilot fall asleep on the control panel
     */
    public void actLikeDrunken() {
        int[] angle = {-1, 0, 1};
        boolean[] acc = {true, false};
        int index_3 = (int) Math.floor(Math.random() * 3);
        int index_2 = (int) Math.floor(Math.random() * 2);
        ship.myPhysics.move(acc[index_2], angle[index_3]);
    }

    /**
     * this spaceship changes it's technique every 3 seconds.
     */
    public void actLikeSpecial() {
        int val = ship.specialCounter % 20;
        if (0 < val && val < 7) {
            actLikeAggressive();
        } else if (7 > val) {
            actLikeBasher();
        } else if (14 > val) {
            actLikeRunner();
        } else if (val == 0) {
            actLikeHuman();
        }
        ship.specialCounter++;
    }
}