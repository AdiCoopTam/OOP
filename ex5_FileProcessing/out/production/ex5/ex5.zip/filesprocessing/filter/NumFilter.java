package filesprocessing.filter;

import java.io.File;

class NumFilter extends SuperFilter {

    /** the range the filter use to filter the files*/
    private double[] range;

    /** the constructor of the filter */
    NumFilter(double[] range, String type, boolean posOrNeg){
        super(posOrNeg, type);
        this.range = range;
    }

    /** a condition to filter by. */
    @Override
    protected boolean condition(File file){
        if(this.type.equals("greater_than")){
            return file.length() >= this.range[1] *1024;
        }
        return this.range[0] <= file.length()/Math.pow(10, 3)
                && file.length() <= this.range[1] * 1024;
    }

}
