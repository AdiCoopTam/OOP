package filesprocessing.filter;

import java.io.File;

class LiteralFilter extends SuperFilter {
    /** the String we will use to compare to the files we have*/
    private String str;

    /** the constructor of the filter */
    LiteralFilter(boolean posOrNeg, String type, String str) {
        super(posOrNeg, type);
        this.str = str;
    }

    /**
     * chooses the right filtering condition for the filter type
     *
     * @param file the file we are inspecting
     *
     * @return boolean - if the file supports the condition or not
     * */
    protected boolean condition(File file){
        switch (this.type){
            case "file":
                return file.getName().equals(this.str);
            case "contains":
                return file.getName().contains(this.str);
            case "prefix":
                return file.getName().startsWith(this.str);
            case "suffix":
                return file.getName().endsWith(this.str);
        }
        return true;
    }
}
