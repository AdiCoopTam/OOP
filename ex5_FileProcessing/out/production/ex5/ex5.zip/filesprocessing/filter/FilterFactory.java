package filesprocessing.filter;

import filesprocessing.exceptions.ExceptionType1;

public class FilterFactory {
    private static final String[] NUMERAL_OPTION = {"greater_than", "between", "smaller_than",
            "smaller_than"}; // I just made them all the same length
    private static final String[] BOOL_OPTION = {"writable", "executable", "hidden", "hidden"};
    private static final String[] LITERAL_OPTION = {"file", "contains", "prefix", "suffix"};
    private static final String ALL = "all";
    private static final String BETWEEN = "between";
    private static final String GREATER = "greater_than";
    private static final String NO = "NO";
    private static final String NOT = "NOT";


    /**
     * an array that gathers all the relevant information about the filter
     */
    private String[] infoArray;


    /**
     * the line of the filter properties
     */
    private long line;

    /**
     * the type of the filter we are going to create
     */
    private String type;

    public FilterFactory(long line, String rawInput) {
        this.line = line;
        this.infoArray = rawInput.split("#");
        this.type = this.infoArray[0];
    }

    /**
     * this method checks if the filter has a "NOT" action
     */
    private boolean haveNot() {
        return !(this.infoArray[this.infoArray.length - 1]).equals(NOT);
    }

    /**
     * the filter creator.
     *
     * @return the filter the want to create by the information we've got
     */
    public SuperFilter filterFactory() throws ExceptionType1 {
        for (int i = 0; i < 4; i++)
            if (this.type.equals(NUMERAL_OPTION[i])) {
                return numeralChecking();
            } else if (this.type.equals(LITERAL_OPTION[i])) {
                return literalFactory();
            } else if (this.type.equals(BOOL_OPTION[i])) {
                return booleanChecking();
            }
            else if (this.type.equals(ALL)){
                return generalFactory();
            }
        throw new ExceptionType1(line);}


    /**
     * checks if the numbers for the numeral filters are valid
     *
     * @return generic filter if there is a problem, numeral filter else.
     */
    private SuperFilter numeralChecking() throws ExceptionType1 {
        try{if (this.type.equals(BETWEEN)){
            if (Double.parseDouble(this.infoArray[1]) > Double.parseDouble(this.infoArray[2])){
            throw new ExceptionType1(this.line);
        }
        }
        if (Double.parseDouble(this.infoArray[1]) < 0) {
            throw new ExceptionType1(this.line);
        }
        return numeralFactory();}
        catch (IllegalArgumentException err){
            throw new ExceptionType1(this.line);
        }
    }


    /**
     * creates a numeral-kind filter
     *
     * @return a numFilter object, with the given information.
     */
    private SuperFilter numeralFactory() {
        if (this.type.equals(BETWEEN)) {
            double[] range = {Double.parseDouble(infoArray[1]), Double.parseDouble(infoArray[2])};
            return new NumFilter(range, this.type, haveNot());
        } else if (this.type.equals(GREATER)) {
            double[] range = {0, Double.parseDouble(infoArray[1])};
            return new NumFilter(range, this.type, haveNot());
        }
        double[] range = {0, Double.parseDouble(infoArray[1])};
        return new NumFilter(range, this.type, haveNot());

    }


    /**
     * checks if the numbers for the boolean filters are valid
     *
     * @return generic filter if there is a problem, boolean filter else.
     */
    private SuperFilter booleanChecking() throws ExceptionType1 {
        try {
            if (!this.infoArray[1].equals(NO) && !this.infoArray[1].equals("YES")) {
                throw new ExceptionType1(line);
            }
        }
        catch (IndexOutOfBoundsException e){
            throw new ExceptionType1(line);
        }
        return booleanFactory();
    }

    /**
     * creates a boolean-kind filter
     *
     * @return a boolFilter object, with the given information.
     */
    private BoolFilter booleanFactory() {
        if (infoArray[1].equals("NO")) {
            return new BoolFilter(haveNot(), this.type, false);
        }
        return new BoolFilter(haveNot(), this.type, true);


    }

    /**
     * creates a literal-kind filter
     *
     * @return a literalFilter object, with the given information.
     */
    private LiteralFilter literalFactory() {
        return new LiteralFilter(haveNot(), this.type, infoArray[1]);
    }

    /**
     * creates a general filter, which is "all" filter.
     *
     * @return a "all" type object, with the given information.
     */
    private SuperFilter generalFactory(){
        return new SuperFilter(haveNot());
    }
}


