package filesprocessing.filter;

import java.io.File;
import java.util.ArrayList;

/** this is an abstract class that guides the different filters*/

public class SuperFilter {

    /**
     * boolean parameter that defines if the filter is negative or positive
     */
    private boolean posOrNeg;

    /**
     * parameter that defines the filter type
     */
    String type;

    /**
     * parameter that represents the results of the filtering
     */
    private ArrayList<File> filesOutput;


    /** a constructor for specific type of filter */
    SuperFilter(boolean posOrNeg, String type) {
        this.posOrNeg = posOrNeg;
        this.type = type;
        this.filesOutput = new ArrayList<>();
    }

    /** an default constructor for "all" */
    SuperFilter(boolean posOrNeg) {
        this.posOrNeg = posOrNeg;
        this.type = "all";
        this.filesOutput = new ArrayList<>();
    }

    /** an default constructor if errors occur */
    public SuperFilter() {
        this.posOrNeg = true;
        this.type = "all";
        this.filesOutput = new ArrayList<>();
    }


    /**
     * the method that's doing the actual filtering action, by thre filtering condition it gets.
     *
     * @return the filtered files array.
     * */
    public ArrayList<File> action(ArrayList<File> filesInput) {
        ArrayList<File> filesInputClone = new ArrayList<>(filesInput);
        for (File file : filesInput) {
            if (condition(file)) {
                this.filesOutput.add(file);
                filesInputClone.remove(file);
            }
        }
        return setByPosNeg(filesInputClone);
    }

    /** a condition to filter by. the default is no filter (for "all")*/
    protected boolean condition (File file){
        return true;
    }

    /** this method defines if the */
    private ArrayList<File> setByPosNeg (ArrayList<File> filesInputClone) {
        if (this.posOrNeg) {
            return this.filesOutput;
        }
        return filesInputClone;
    }
}