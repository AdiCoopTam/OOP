package filesprocessing.filter;

import java.io.File;

class BoolFilter extends SuperFilter {

    /** the boolean value that guides the condition of the filter */
    private boolean yesNo;

    /** the constructor of the class */
    BoolFilter(boolean posOrNeg, String type, boolean yesNo) {
        super(posOrNeg, type);
        this.yesNo = yesNo;
    }

    /**
     * chooses the right filtering condition for the filter type
     *
     * @param file the file we are inspecting
     *
     * @return boolean - if the file supports the condition or not
     * */
    @Override
    protected boolean condition(File file){
        switch (this.type){
            case "writable":
                return file.canWrite() == this.yesNo;
            case "executable":
                return file.canExecute() == this.yesNo;
            case "hidden":
                return file.isHidden() == this.yesNo;
        }
        return true;
    }
}
