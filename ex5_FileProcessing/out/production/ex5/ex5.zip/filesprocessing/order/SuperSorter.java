package filesprocessing.order;

import java.io.File;

/** this is a class which all the sorters are heritage from*/
public abstract class SuperSorter {

    /**
     * a boolean constructor to define if the sorter is reversed or not
     */
    boolean isReverse;

    /**
     * the rule of the sorting, by the sorter kind
     *
     * @param file1 - the first file we will compare.
     * @param file2 - the second file we will compare.
     *
     * @return positive number if file 1 should be before file 2; negative number otherwise.
     *
     */
    protected abstract double rule(File file1, File file2);

    /**
     * sorting for the files, using "Insert Sort".
     */
    public void insertSort(File[] arrayOfFiles) {
        {
            int n = arrayOfFiles.length;
            for (int i = 1; i < n; ++i) {
                File pivot = arrayOfFiles[i];
                int j = i - 1;
                while (j >= 0 && rule(arrayOfFiles[j],pivot) > 0 ) {
                    arrayOfFiles[j + 1] = arrayOfFiles[j];
                    j = j - 1;
                }
                arrayOfFiles[j + 1] = pivot;
            }
        }
    }
}




