package filesprocessing.order;

import filesprocessing.exceptions.ExceptionType1;

/** this class builds Sorters by given information */
public class SorterFactory {
    private static final String ABS = "abs";
    private static final String SIZE = "size";
    private static final String TYPE = "type";
    private static final String NEGATIVE = "REVERSE";


    /**
     * an array that gathers all the relevant information about the filter
     */
    private String[] infoArray;

    /**
     * the line of the filter properties
     */
    private long line;

    /**
     * the type of the filter we are going to create
     */
    private String type;

    public SorterFactory(long line, String rawInput) {
        this.line = line;
        this.infoArray = rawInput.split("#");
        this.type = this.infoArray[0];
    }

    /**
     * this method checks if the filter has a "NOT" action
     */
    private boolean haveReverse() {
        return (this.infoArray[this.infoArray.length - 1]).equals(NEGATIVE);
    }

    /**
     * the filter creator.
     *
     * @return the filter the want to create by the information we've got
     */
    public SuperSorter sorterFactory() throws ExceptionType1 {
        switch (this.type) {
                case ABS:
                    return new AbsSorter(haveReverse());
                case TYPE:
                    return new TypeSorter(haveReverse());
                    case SIZE:
                        return new SizeSorter(haveReverse());
                }
        throw new ExceptionType1(this.line);
    }}



