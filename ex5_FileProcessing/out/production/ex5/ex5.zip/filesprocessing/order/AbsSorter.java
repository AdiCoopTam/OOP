package filesprocessing.order;

import java.io.File;

public class AbsSorter extends SuperSorter {

    /**
     * a boolean constructor to define if the sorter is reversed or not
     */
    protected boolean isReverse;

    /**
     * the sorter constructor
     */
    AbsSorter(boolean isReverse) {
        this.isReverse = isReverse;
    }


    /**
     * the default constructor
     */
    public AbsSorter() {
        this.isReverse = false;
    }

    /**
     * the rule of the sorting, by the sorter kind
     *
     * @param file1 - the first file we will compare.
     * @param file2 - the second file we will compare.
     *
     * @return positive number if file 1 should be before file 2; negative number otherwise.
     *
     */
    protected double rule(File file1, File file2) {
        int result = file1.getName().compareTo(file2.getName());
        if (isReverse) {
            return (-1) * (result);
        }
        return result;
    }
}