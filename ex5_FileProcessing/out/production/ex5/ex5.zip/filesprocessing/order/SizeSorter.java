package filesprocessing.order;

import java.io.File;

public class SizeSorter extends SuperSorter {
    /**
     * the sorter constructor
     *
     * @param isReverse - true is should be reverse, false else
     */
    SizeSorter(boolean isReverse) {
        this.isReverse = isReverse;
    }

    /**
     * the rule of the sorting, by the sorter kind
     *
     * @return positive number if file 1 should be before file 2; negative number otherwise.
     */
    @Override
    protected double rule(File file1, File file2) {
        if (isReverse){
            return (-1)*((file1.length()*Math.pow(1024, -1) - file2.length()*Math.pow(1024, -1)));
        }
        return (file1.length()*Math.pow(1024, -1) - file2.length()*Math.pow(1024, -1));
    }
}

