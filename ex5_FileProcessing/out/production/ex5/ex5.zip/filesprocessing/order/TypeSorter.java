package filesprocessing.order;

import java.io.File;

public class TypeSorter extends SuperSorter {
    /**
     * the sorter constructor
     *
     * @param isReverse - true is should be reversed, false else
     */
    TypeSorter(boolean isReverse) {
        this.isReverse = isReverse;
    }

    /**
     * the rule of the sorting, by the sorter kind
     *
     * @param file1 - the first file we will compare.
     * @param file2 - the second file we will compare.
     *
     * @return positive number if file 1 should be before file 2; negative number otherwise.
     */
    @Override
    protected double rule(File file1, File file2){
        if (this.isReverse){
            return (-1) * getFileExtension(file1).compareTo(getFileExtension(file2));}
        else{
            return getFileExtension(file1).compareTo(getFileExtension(file2));
        }
    }

    /**
     * an assistant function for getting the file extension
     *
     * @param file - the file we are inspecting
     * @return the extension of the file
     * */
    private String getFileExtension(File file){
        int i = file.getName().lastIndexOf('.');
        try{
            return file.getName().substring(i + 1);
        }
        catch (IndexOutOfBoundsException e){
            return ".File";
        }
    }
}
