package filesprocessing;

import filesprocessing.exceptions.ExceptionType2;

public class DirectoryProcessor {

    public static void main(String[] args){
        try {
            InputFactory.printer(args);
        }
        catch (ExceptionType2 exceptionType2){
            System.err.println(exceptionType2.getMessage());
        }
}
}
