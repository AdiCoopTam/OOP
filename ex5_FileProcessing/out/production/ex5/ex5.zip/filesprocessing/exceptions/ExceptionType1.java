package filesprocessing.exceptions;

/** this class gives a function that prints error message without stopping the code from running */
public class ExceptionType1 extends Exception {

    /**the exception constructor*/
    public ExceptionType1(long line){
        super("Warning in line " + (line));
    }

}
