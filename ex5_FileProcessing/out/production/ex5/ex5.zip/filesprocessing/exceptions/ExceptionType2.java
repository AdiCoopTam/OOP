package filesprocessing.exceptions;

/**
 * this class defines main kinds of possible errors and gives the right error message to the right
 * exception kind.
 * */

public class ExceptionType2 extends Exception {

    /** the constructor of the class, based on an assist method */
    public ExceptionType2(String kind){
        super(chooseError(kind));
    }
    /**
     * this function picks the right ERROR message for the current problem.

     * */
    private static String chooseError(String kind){
        switch (kind){
            case "INPUT":
                return "ERROR: wrong input given in the command line";
            case "IO":
                return "ERROR: Input-Output problem - something went wrong with the command file";
            case "FILTER":
                return "ERROR: The filter sub-section is not spelled right or missing";
            case "ORDER":
                return "ERROR: The order sub-section is not spelled right or missing";

        }
        return "";
    }


}
