package filesprocessing;

import filesprocessing.exceptions.*;
import filesprocessing.section.Section;
import filesprocessing.section.SectionFactory;
import filesprocessing.section.SectionInfoWrap;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;


class InputFactory {

    /**
     * the original command line
     */
    private String[] input;

    /**
     * constants to use on the way
     */
    private static final String FILTER = "FILTER";
    private static final String IO = "IO";
    private static final String INPUT = "INPUT";

    /**
     * the constructor of the class
     */
    private InputFactory(String[] input) {
        this.input = input;
    }

    /**
     * checks the if the input in valid
     */
    private void checker() throws ExceptionType2 {
        if (this.input.length != 2) {
            throw new ExceptionType2(INPUT);
        }

        File sourceDir = new File(this.input[0]);
        File commandFile = new File(this.input[1]);

        if (!commandFile.isFile() || !sourceDir.isDirectory()) {
            throw new ExceptionType2(INPUT);
        }
        if(sourceDir.list().length == 0){
            throw new ExceptionType2(INPUT);
        }
    }


    /**
     * this is a function that extract the files from the directory to an ArrayList
     *
     * @return Array of files we will inspect.
     */
    private ArrayList<File> extractDirectory() throws ExceptionType2{
        checker();
        File sourceDir = new File(this.input[0]);
        ArrayList<File> files = new ArrayList<>();
        for(File file: Objects.requireNonNull(sourceDir.listFiles()))
            if (!file.isDirectory()){
                files.add(file);
            }
        return files;
    }

    /**
     * this method convert the command file to array of strings
     *
     * @return the content of the command file
     */
    private ArrayList<String> extractCommandFile() throws ExceptionType2 {
        checker();
        try {
            ArrayList<String> arrayList = new ArrayList<>();
            Stream<String> streamer = Files.lines(Path.of(this.input[1]));
            streamer.forEach(arrayList::add);
            return arrayList;
        } catch (IOException e) {
            throw new ExceptionType2(IO);
        }
    }

    /**
     * this method splits the command file information into little units of information.
     *
     * @return ArrayList of LinkedList that includes the
     */
    private ArrayList<SectionInfoWrap> splitter() throws ExceptionType2 {
        ArrayList<SectionInfoWrap> parts = new ArrayList<>();
        LinkedList<String> linked = new LinkedList<>();
        ArrayList<String> rawInfoArray = extractCommandFile();
        for (int i = 0; i < rawInfoArray.size(); i++) {
            linked.add(rawInfoArray.get(i));
            try { if (linked.size() == 4 || rawInfoArray.get(i + 1).equals(FILTER)) {
                if(!rawInfoArray.get(i + 2).equals(FILTER)){
                    cloneLinked(linked, i -linked.size() + 1, parts);
            }}
            }
            catch (IndexOutOfBoundsException e){
                cloneLinked(linked, i - linked.size() +1, parts);
            }
        }
        return parts;
    }

    private void cloneLinked(LinkedList<String> linkedList, int i, ArrayList<SectionInfoWrap> parts){
        LinkedList<String> linkedClone = new LinkedList<>(linkedList);
        parts.add(new SectionInfoWrap(linkedClone, i+1));
        linkedList.clear();
    }


    /**
     *  the printer of the filtered and organized files
     *
     * @param args - the input from the command line
     * */
    static void printer(String[] args) throws ExceptionType2 {
        InputFactory input = new InputFactory(args);
        for (int i=0; i<input.splitter().size(); i++){
            SectionFactory factory = new SectionFactory(input.extractDirectory());
            SectionInfoWrap sectionInfo = input.splitter().get(i);
            Section section = factory.infoToSection(sectionInfo.information, sectionInfo.beginLine);
            File[] result = section.processing();
            for (File res : result) {
                System.out.println(res.getName());
            }
        }
    }
}


