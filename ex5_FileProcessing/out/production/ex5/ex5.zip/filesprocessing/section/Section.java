package filesprocessing.section;

import filesprocessing.filter.SuperFilter;
import filesprocessing.order.SuperSorter;

import java.io.File;
import java.util.ArrayList;


/** a section that includes combination of filter and sorter */
public class Section {

    /** the array we are going to process*/
    private ArrayList<File> filesInput;

    /** the filter we are going to use */
    private SuperFilter filter;

    /** the sorter we are going to sort with */
    private SuperSorter sorter;


    /** the constructor of the class */
    Section(ArrayList<File> filesInput,SuperFilter filter, SuperSorter sorter){
        this.filesInput = filesInput;
        this.filter = filter;
        this.sorter = sorter;
    }

    /** the processing, well, process the files*/
    public File[] processing(){
        ArrayList<File> result = filter.action(filesInput);
        File[] files = new File[result.size()];
        for(int i=0; i < result.size(); i++) {
            files[i] = result.get(i);
        }
        sorter.insertSort(files);
        return files;
    }
}
