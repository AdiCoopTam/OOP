package filesprocessing.section;

import filesprocessing.exceptions.*;
import filesprocessing.filter.FilterFactory;
import filesprocessing.filter.SuperFilter;
import filesprocessing.order.*;


import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;

/** this class creates Section from the information we've got*/
public class SectionFactory{
    /**constants to use*/
    private static final String FILTER = "FILTER";
    private static final String ORDER = "ORDER";

    /** all the input-files info */
    private ArrayList<File> inputFiles;


    /** the constructor of the class*/
    public SectionFactory(ArrayList<File> inputFiles){
        this.inputFiles = inputFiles;
    }


    /**
     *  this function checks if the section is valid
     *
     * @param linkedList - a list of the info about the section.
     *
     * @param linkedList - the info about the section
     * */
    private void checkForType2(LinkedList<String> linkedList) throws ExceptionType2{
        if (linkedList.size()< 2){
            throw new ExceptionType2(ORDER);
        }
        if (!linkedList.get(0).equals(FILTER)){
            throw new ExceptionType2(FILTER);
        }
        for (int i = 1; i< linkedList.size(); i++){
            if (linkedList.get(i).equals(ORDER)){
                return;
            }
        }
        throw new ExceptionType2(ORDER);
    }


    /**
     * this function takes the command file content and turn it into a Section object that includes a filter
     * and a sorter. Throws exception if needed.
     *
     * @param beginLine  - the line where the whole section begins.
     * @param linkedList - a list of the info about the section.
     *
     * @return a proper Section object.
     *
     * */
    public Section infoToSection(LinkedList<String> linkedList, int beginLine) throws ExceptionType2 {
        checkForType2(linkedList);
        SuperFilter filter = extractFilter(linkedList, beginLine);
        SuperSorter superSorter = extractSorter(linkedList, beginLine);
        return new Section(this.inputFiles, filter, superSorter);
    }

    /**
     * this function takes the command file content and turn it into a filter object.
     * Throws exception if needed.
     *
     * @param beginLine  - the line where the whole section begins.
     * @param linkedList - a list of the info about the section.
     *
     * @return a proper filter object.
     *
     * */
    private SuperFilter extractFilter(LinkedList<String> linkedList, int beginLine){
        try {
                return new FilterFactory(beginLine + 1, linkedList.get(1)).filterFactory();}
        catch (ExceptionType1 err){
            ExceptionType1 exceptionType1 = new ExceptionType1(beginLine + 1);
            System.err.println(exceptionType1.getMessage());
            return new SuperFilter();
        }
}

    /**
     * this function takes the command file content and turn it into a Sorter object.
     * Throws exception if needed.
     *
     * @param beginLine  - the line where the whole section begins.
     * @param linkedList - a list of the info about the section.
     *
     * @return a proper Sorter object.
     *
     * */
    private SuperSorter extractSorter(LinkedList<String> linkedList, int beginLine) {
        for (int i = 1; i < linkedList.size(); i++) {
            if (linkedList.get(i).equals(ORDER)) {
                try {
                    return new SorterFactory(beginLine + 3, linkedList.get(i + 1)).sorterFactory();
                } catch (IndexOutOfBoundsException e) {
                    return new AbsSorter();
                }
                catch (ExceptionType1 e){
                    System.err.println(e.getMessage());
                    return new AbsSorter();
                }
                }
            }
        return new AbsSorter();
    }
    }
