package filesprocessing.section;

import java.util.LinkedList;

/** this class wraps the raw information we get from the input about the section*/
public class SectionInfoWrap {
    /** a linked list that includes the info about the section*/
    public LinkedList<String> information;

    /** the line where the section description begins in the */
    public int beginLine;

    public SectionInfoWrap(LinkedList<String> information, int beginLine){
        this.information = information;
        this.beginLine = beginLine;
    }

}
